from flask import Flask, request, jsonify, session
from werkzeug.security import generate_password_hash, check_password_hash
from flask import Flask
from flask_cors import CORS
import pyodbc
import datetime
import os

app = Flask(__name__)
CORS(app, supports_credentials=True)


# Helper function to build a CORS preflight response
def _build_cors_preflight_response():
    response = jsonify({})
    response.headers.add("Access-Control-Allow-Origin", "*")
    response.headers.add('Access-Control-Allow-Headers', "*")
    response.headers.add('Access-Control-Allow-Methods', "*")
    return response


app.secret_key = os.getenv('FLASK_SECRET_KEY', 'default_key')  # Use an environment variable

# Ensuring sessions are persistent
app.config['SESSION_PERMANENT'] = False
app.config['SESSION_TYPE'] = 'filesystem'

# Database connection setup
def get_db_connection():
    server = os.getenv('DB_SERVER', 'ecommdb.database.windows.net')
    database = os.getenv('DB_NAME', 'ecommerce_webscrappingDB')
    username = os.getenv('DB_USERNAME', 'dbadmin')
    password = os.getenv('DB_PASSWORD', 'Perro1201')
    driver = 'ODBC Driver 17 for SQL Server'
    connection_string = f'DRIVER={{{driver}}};SERVER=tcp:{server},1433;DATABASE={database};UID={username};PWD={password};Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;'
    return pyodbc.connect(connection_string)

# Helper function to check for existing username
def username_exists(username):
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM users WHERE username = ?", (username,))
        return cursor.fetchone()[0] > 0

# Login endpoint
@app.route('/login', methods=['POST'])
def login():
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            username = request.json.get('username')
            password = request.json.get('password')

            # Basic input validation
            if not username or not password:
                return jsonify({"success": False, "message": "Username and password are required"}), 400

            if len(username) < 3 or len(username) > 20:
                return jsonify({"success": False, "message": "Username must be between 3 and 20 characters"}), 400

            if len(password) < 8:
                return jsonify({"success": False, "message": "Password must be at least 8 characters long"}), 400

            cursor.execute("SELECT user_id, password, is_admin FROM users WHERE username = ?", (username,))
            user = cursor.fetchone()

            if user and check_password_hash(user[1], password):  # user[1] is the hashed password
                session['user_id'] = user[0]  # user[0] is the user_id
                session['is_admin'] = user[2]  # user[2] is the is_admin flag
                session['userLoggedIn'] = True  # Set a flag indicating the user is logged in
                return jsonify({"success": True, "is_admin": user[2], "user_id": user[0], "userLoggedIn": True})
            else:
                return jsonify({"success": False, "message": "Invalid username or password"}), 401
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

# User registration endpoint
@app.route('/register', methods=['POST', 'OPTIONS'])
def register():
    # Handle the OPTIONS request for CORS preflight
    if request.method == 'OPTIONS':
        return _build_cors_preflight_response()

    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()

            username = request.json.get('username')
            password = request.json.get('password')
            is_admin = False  # Regular users are not admins

            # Basic input validation
            if not username or not password:
                return jsonify({"success": False, "message": "Username and password are required"}), 400

            # Check for existing username
            if username_exists(username):
                return jsonify({"success": False, "message": "Username already exists"}), 400

            hashed_password = generate_password_hash(password)

            cursor.execute("INSERT INTO users (username, password, is_admin) VALUES (?, ?, ?)", (username, hashed_password, is_admin))
            conn.commit()
            return jsonify({"success": True, "message": "User registered successfully"})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

    
# Admin user registration endpoint
@app.route('/register_admin', methods=['POST'])
def register_admin():
    
    app.logger.info(f"Admin registration attempt. User ID: {session.get('user_id')}, Is Admin: {session.get('is_admin')}")  # Log the session details

    user_id = session.get('user_id')
    is_admin = session.get('is_admin', False)

    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()

            username = request.json.get('username')
            password = request.json.get('password')
            is_admin = True  # This user will be an admin

            # Basic input validation
            if not username or not password:
                return jsonify({"success": False, "message": "Username and password are required"}), 400

            # Check for existing username
            if username_exists(username):
                return jsonify({"success": False, "message": "Username already exists"}), 400

            hashed_password = generate_password_hash(password)

            cursor.execute("INSERT INTO users (username, password, is_admin) VALUES (?, ?, ?)", (username, hashed_password, is_admin))
            conn.commit()
            return jsonify({"success": True, "message": "Admin user registered successfully"}), 201
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

# Logout endpoint
@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('is_admin', None)
    return jsonify({"success": True})


#PURCHASE ENDPOINT

@app.route('/api/purchases', methods=['POST'])
def handle_purchases():
    try:
        # Extracting data from the request
        data = request.json
        name = data['name']
        address = data['address']
        email = data['email']
        phone = data['phone']
        product_url = data['product_url']  # Extracting product URL
        delivery_status = "In Progress"  # Initial status

        # Connect to the database
        conn = get_db_connection()
        cursor = conn.cursor()

        # Insert user info into user_info table and get the new user_info_id
        cursor.execute("INSERT INTO user_info (name, address, email, phone) VALUES (?, ?, ?, ?)", (name, address, email, phone))
        user_info_id = cursor.execute("SELECT @@IDENTITY AS id;").fetchval()

        # Retrieve user_id from the request (logged-in user)
        user_id = data.get('user_id')

        # Insert order into orders table, including both user_id and user_info_id, and product_url
        current_time = datetime.datetime.now()
        cursor.execute("INSERT INTO orders (user_id, user_info_id, order_date, delivery_status, product_url) VALUES (?, ?, ?, ?, ?)", (user_id, user_info_id, current_time, delivery_status, product_url))
        order_id = cursor.execute("SELECT @@IDENTITY AS id;").fetchval()

        # Commit the transaction and close the connection
        conn.commit()
        cursor.close()
        conn.close()

        return jsonify({"success": True, "order_id": order_id, "user_info_id": user_info_id}), 201
    except Exception as e:
        if conn:
            conn.rollback()  # Rollback in case of error
        if cursor:
            cursor.close()
        if conn:
            conn.close()
        return jsonify({"error": str(e)}), 500
    


# CHECK USERNAME ENDPOINT

@app.route('/check-username', methods=['POST'])
def check_username():
    try:
        username = request.json.get('username')

        if not username:
            return jsonify({"success": False, "message": "Username is required"}), 400

        conn = get_db_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT COUNT(1) FROM users WHERE username = ?", (username,))
        exists = cursor.fetchone()[0]

        cursor.close()
        conn.close()

        return jsonify({"success": True, "exists": bool(exists)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


    
if __name__ == "__main__":
    app.run(port=5010)

if __name__ == '__main__':
    app.run(debug=True)
    


