from flask import Flask, jsonify, request
from bs4 import BeautifulSoup
from flask_cors import CORS
import requests
import pyodbc
import os
app = Flask(__name__)
CORS(app)


def scrape_category(url, category_name):
    """
    This function scrapes a specific category URL and returns a list of product information dictionaries.

    Args:
        url: The URL of the category page.
        category_name: The name of the category.

    Returns:
        A list of dictionaries, each containing information about a product.
    """
    response = requests.get(url)
    html_content = response.text
    soup = BeautifulSoup(html_content, 'html.parser')

    product_containers = soup.find_all('div', {'class': 'hugo4-pc-grid-item'})
    all_products_info = []

    for container in product_containers:
        product_info = {}  # Initialize an empty dictionary for each product

        # Extract product information
        title_tag = container.find('span', {'title': True})
        product_info['title'] = title_tag.get('title') if title_tag else 'No title found'

        picture_tag = container.find('img', {'class': 'picture-image'})
        product_info['picture_url'] = picture_tag['src'] if picture_tag else 'No image found'

        price_tag = container.find('div', {'class': 'hugo4-product-price-area'})
        product_info['price'] = price_tag.get_text(strip=True) if price_tag else 'No price found'

        link_tag = container.find('a', href=True)
        product_info['link'] = link_tag['href'] if link_tag else 'No link found'

        all_products_info.append(product_info)

    return all_products_info


@app.route('/api/search')
def search_products():
    """
    This function searches for products across all categories based on a query string.

    Returns:
        A JSON response containing a list of product information dictionaries matching the search query.
    """
    query = request.args.get('query', '').lower()
    all_products = []

    # Define dictionary of category URLs and names
    categories = { "Featured": 'https://sale.alibaba.com/p/rank/detail.html?spm=a27aq.rank_list.5162911150.1018.25094b26rkGuSZ&wx_navbar_transparent=true&path=/p/rank/detail.html&ncms_spm=a27aq.rank_detail&cardType=101002669&cardId=10001204270&topOfferIds=1600820408806&templateBusinessCode=',    
                  "Phones & Accessories": 'https://sale.alibaba.com/category/theme/index.html?spm=a27aq.cp_44.9890923860.3.1a523ccflsc9Fz&wx_navbar_transparent=true&path=/category/theme/index.html&ncms_spm=a27aq.27059075&prefetchKey=met&cardType=2795402&cardId=2801201&topOfferIds=1600499374407&categoryIds=&tracelog=fy23_all_categories_home_lp',
                  "Computer & Accessories": 'https://sale.alibaba.com/category/theme/index.html?spm=a27aq.cp_44.9890923860.3.1a523ccfPRPcRM&wx_navbar_transparent=true&path=/category/theme/index.html&ncms_spm=a27aq.27059075&prefetchKey=met&cardType=2795402&cardId=2793006&topOfferIds=1600375179404&categoryIds=&tracelog=fy23_all_categories_home_lp',
                  "Gaming": 'https://sale.alibaba.com/category/theme/index.html?spm=a27aq.cp_44.9890923860.4.1a523ccfPRPcRM&wx_navbar_transparent=true&path=/category/theme/index.html&ncms_spm=a27aq.27059075&prefetchKey=met&cardType=2795402&cardId=2801001&topOfferIds=1600266956025&categoryIds=&tracelog=fy23_all_categories_home_lp',
                  "Office Supplies": 'https://sale.alibaba.com/category/theme/index.html?spm=a27aq.cp_44.9890923860.6.1a523ccfPRPcRM&wx_navbar_transparent=true&path=/category/theme/index.html&ncms_spm=a27aq.27059075&prefetchKey=met&cardType=2795402&cardId=2794202&topOfferIds=1600620766260&categoryIds=&tracelog=fy23_all_categories_home_lp',
                 "Auto Detailing": 'https://sale.alibaba.com/category/theme/index.html?spm=a27aq.cp_34.1305889980.5.629c3aa61YjGGA&wx_navbar_transparent=true&path=/category/theme/index.html&ncms_spm=a27aq.27059075&prefetchKey=met&cardType=2710203&cardId=2712205&topOfferIds=1600309049659&categoryIds=34&tracelog=fy23_all_categories_home_lp',
                 "Wheels & Tires": 'https://sale.alibaba.com/category/theme/index.html?spm=a27aq.cp_34.1305889980.3.629c3aa61YjGGA&wx_navbar_transparent=true&path=/category/theme/index.html&ncms_spm=a27aq.27059075&prefetchKey=met&cardType=2710203&cardId=2705406&topOfferIds=1600224866968&categoryIds=34&tracelog=fy23_all_categories_home_lp',
                 "Car Accessories": 'https://sale.alibaba.com/category/theme/index.html?spm=a27aq.cp_34.1305889980.4.629c3aa61YjGGA&wx_navbar_transparent=true&path=/category/theme/index.html&ncms_spm=a27aq.27059075&prefetchKey=met&cardType=2710203&cardId=2709003&topOfferIds=1600506702051&categoryIds=34&tracelog=fy23_all_categories_home_lp',
                 "Sneakers": 'https://sale.alibaba.com/p/rank/detail.html?spm=a27aq.rank_list.5162911150.21.53904b269F48pJ&wx_navbar_transparent=true&path=/p/rank/detail.html&ncms_spm=a27aq.rank_detail&cardType=101002669&cardId=10001335854&topOfferIds=1600642960462&templateBusinessCode=',
                 "Boots": 'https://sale.alibaba.com/p/rank/detail.html?spm=a27aq.rank_list.5162911150.5.53904b269F48pJ&wx_navbar_transparent=true&path=/p/rank/detail.html&ncms_spm=a27aq.rank_detail&cardType=101002669&cardId=10001288287&topOfferIds=1600619698820&templateBusinessCode='
   }

    # Scrape each category and aggregate products
    for category_name, url in categories.items():
        print(f"Scraping category: {category_name}")
        category_products = scrape_category(url, category_name)
        all_products.extend(category_products)
        print(f"Total products for {category_name}: {len(category_products)}")

    print(f"Total products before filtering: {len(all_products)}")

    # Filter products based on query
    filtered_products = [product for product in all_products if query in product['title'].lower()]
    print(f"Total products after filtering for '{query}': {len(filtered_products)}")

    return jsonify(filtered_products)


@app.route('/api/<category_name>')
def get_category_data(category_name):
    """
    This function retrieves all products for a specific category.

    Args:
        category_name: The name of the category.

    Returns:
        A JSON response containing a list of product information dictionaries for the specified category.
    """
    categories = { "Featured": 'https://sale.alibaba.com/p/rank/detail.html?spm=a27aq.rank_list.5162911150.1018.25094b26rkGuSZ&wx_navbar_transparent=true&path=/p/rank/detail.html&ncms_spm=a27aq.rank_detail&cardType=101002669&cardId=10001204270&topOfferIds=1600820408806&templateBusinessCode=',    
                  "Phones & Accessories": 'https://sale.alibaba.com/category/theme/index.html?spm=a27aq.cp_44.9890923860.3.1a523ccflsc9Fz&wx_navbar_transparent=true&path=/category/theme/index.html&ncms_spm=a27aq.27059075&prefetchKey=met&cardType=2795402&cardId=2801201&topOfferIds=1600499374407&categoryIds=&tracelog=fy23_all_categories_home_lp',
                  "Computer & Accessories": 'https://sale.alibaba.com/category/theme/index.html?spm=a27aq.cp_44.9890923860.3.1a523ccfPRPcRM&wx_navbar_transparent=true&path=/category/theme/index.html&ncms_spm=a27aq.27059075&prefetchKey=met&cardType=2795402&cardId=2793006&topOfferIds=1600375179404&categoryIds=&tracelog=fy23_all_categories_home_lp',
                  "Gaming": 'https://sale.alibaba.com/category/theme/index.html?spm=a27aq.cp_44.9890923860.4.1a523ccfPRPcRM&wx_navbar_transparent=true&path=/category/theme/index.html&ncms_spm=a27aq.27059075&prefetchKey=met&cardType=2795402&cardId=2801001&topOfferIds=1600266956025&categoryIds=&tracelog=fy23_all_categories_home_lp',
                  "Office Supplies": 'https://sale.alibaba.com/category/theme/index.html?spm=a27aq.cp_44.9890923860.6.1a523ccfPRPcRM&wx_navbar_transparent=true&path=/category/theme/index.html&ncms_spm=a27aq.27059075&prefetchKey=met&cardType=2795402&cardId=2794202&topOfferIds=1600620766260&categoryIds=&tracelog=fy23_all_categories_home_lp',
                 "Auto Detailing": 'https://sale.alibaba.com/category/theme/index.html?spm=a27aq.cp_34.1305889980.5.629c3aa61YjGGA&wx_navbar_transparent=true&path=/category/theme/index.html&ncms_spm=a27aq.27059075&prefetchKey=met&cardType=2710203&cardId=2712205&topOfferIds=1600309049659&categoryIds=34&tracelog=fy23_all_categories_home_lp',
                 "Wheels & Tires": 'https://sale.alibaba.com/category/theme/index.html?spm=a27aq.cp_34.1305889980.3.629c3aa61YjGGA&wx_navbar_transparent=true&path=/category/theme/index.html&ncms_spm=a27aq.27059075&prefetchKey=met&cardType=2710203&cardId=2705406&topOfferIds=1600224866968&categoryIds=34&tracelog=fy23_all_categories_home_lp',
                 "Car Accessories": 'https://sale.alibaba.com/category/theme/index.html?spm=a27aq.cp_34.1305889980.4.629c3aa61YjGGA&wx_navbar_transparent=true&path=/category/theme/index.html&ncms_spm=a27aq.27059075&prefetchKey=met&cardType=2710203&cardId=2709003&topOfferIds=1600506702051&categoryIds=34&tracelog=fy23_all_categories_home_lp',
                 "Sneakers": 'https://sale.alibaba.com/p/rank/detail.html?spm=a27aq.rank_list.5162911150.21.53904b269F48pJ&wx_navbar_transparent=true&path=/p/rank/detail.html&ncms_spm=a27aq.rank_detail&cardType=101002669&cardId=10001335854&topOfferIds=1600642960462&templateBusinessCode=',
                 "Boots": 'https://sale.alibaba.com/p/rank/detail.html?spm=a27aq.rank_list.5162911150.5.53904b269F48pJ&wx_navbar_transparent=true&path=/p/rank/detail.html&ncms_spm=a27aq.rank_detail&cardType=101002669&cardId=10001288287&topOfferIds=1600619698820&templateBusinessCode='
   }

    if category_name not in categories:
        return jsonify({"error": f"Category '{category_name}' not found."}), 404

    url = categories[category_name]
    all_products = scrape_category(url, category_name)

    return jsonify(all_products)


@app.route('/api/all')
def get_all_products():
    """
    This function merges all product data from the other APIs and returns a single JSON response.

    Returns:
        A JSON response containing a list of product information dictionaries from all categories.
    """
    all_products = []

    # Define dictionary of category URLs and names
    categories = { "Featured": 'https://sale.alibaba.com/p/rank/detail.html?spm=a27aq.rank_list.5162911150.1018.25094b26rkGuSZ&wx_navbar_transparent=true&path=/p/rank/detail.html&ncms_spm=a27aq.rank_detail&cardType=101002669&cardId=10001204270&topOfferIds=1600820408806&templateBusinessCode=',    
                  "Phones & Accessories": 'https://sale.alibaba.com/category/theme/index.html?spm=a27aq.cp_44.9890923860.3.1a523ccflsc9Fz&wx_navbar_transparent=true&path=/category/theme/index.html&ncms_spm=a27aq.27059075&prefetchKey=met&cardType=2795402&cardId=2801201&topOfferIds=1600499374407&categoryIds=&tracelog=fy23_all_categories_home_lp',
                  "Computer & Accessories": 'https://sale.alibaba.com/category/theme/index.html?spm=a27aq.cp_44.9890923860.3.1a523ccfPRPcRM&wx_navbar_transparent=true&path=/category/theme/index.html&ncms_spm=a27aq.27059075&prefetchKey=met&cardType=2795402&cardId=2793006&topOfferIds=1600375179404&categoryIds=&tracelog=fy23_all_categories_home_lp',
                  "Gaming": 'https://sale.alibaba.com/category/theme/index.html?spm=a27aq.cp_44.9890923860.4.1a523ccfPRPcRM&wx_navbar_transparent=true&path=/category/theme/index.html&ncms_spm=a27aq.27059075&prefetchKey=met&cardType=2795402&cardId=2801001&topOfferIds=1600266956025&categoryIds=&tracelog=fy23_all_categories_home_lp',
                  "Office Supplies": 'https://sale.alibaba.com/category/theme/index.html?spm=a27aq.cp_44.9890923860.6.1a523ccfPRPcRM&wx_navbar_transparent=true&path=/category/theme/index.html&ncms_spm=a27aq.27059075&prefetchKey=met&cardType=2795402&cardId=2794202&topOfferIds=1600620766260&categoryIds=&tracelog=fy23_all_categories_home_lp',
                 "Auto Detailing": 'https://sale.alibaba.com/category/theme/index.html?spm=a27aq.cp_34.1305889980.5.629c3aa61YjGGA&wx_navbar_transparent=true&path=/category/theme/index.html&ncms_spm=a27aq.27059075&prefetchKey=met&cardType=2710203&cardId=2712205&topOfferIds=1600309049659&categoryIds=34&tracelog=fy23_all_categories_home_lp',
                 "Wheels & Tires": 'https://sale.alibaba.com/category/theme/index.html?spm=a27aq.cp_34.1305889980.3.629c3aa61YjGGA&wx_navbar_transparent=true&path=/category/theme/index.html&ncms_spm=a27aq.27059075&prefetchKey=met&cardType=2710203&cardId=2705406&topOfferIds=1600224866968&categoryIds=34&tracelog=fy23_all_categories_home_lp',
                 "Car Accessories": 'https://sale.alibaba.com/category/theme/index.html?spm=a27aq.cp_34.1305889980.4.629c3aa61YjGGA&wx_navbar_transparent=true&path=/category/theme/index.html&ncms_spm=a27aq.27059075&prefetchKey=met&cardType=2710203&cardId=2709003&topOfferIds=1600506702051&categoryIds=34&tracelog=fy23_all_categories_home_lp',
                 "Sneakers": 'https://sale.alibaba.com/p/rank/detail.html?spm=a27aq.rank_list.5162911150.21.53904b269F48pJ&wx_navbar_transparent=true&path=/p/rank/detail.html&ncms_spm=a27aq.rank_detail&cardType=101002669&cardId=10001335854&topOfferIds=1600642960462&templateBusinessCode=',
                 "Boots": 'https://sale.alibaba.com/p/rank/detail.html?spm=a27aq.rank_list.5162911150.5.53904b269F48pJ&wx_navbar_transparent=true&path=/p/rank/detail.html&ncms_spm=a27aq.rank_detail&cardType=101002669&cardId=10001288287&topOfferIds=1600619698820&templateBusinessCode='
   }

  
    # Scrape each category and aggregate products
    for category_name, url in categories.items():
        print(f"Scraping category: {category_name}")
        category_products = scrape_category(url, category_name)
        all_products.extend(category_products)
        print(f"Total products for {category_name}: {len(category_products)}")

    print(f"Total products: {len(all_products)}")

    return jsonify(all_products)



# Database connection setup
def get_db_connection():
    server = os.getenv('DB_SERVER', 'ecommdb.database.windows.net')
    database = os.getenv('DB_NAME', 'ecommerce_webscrappingDB')
    username = os.getenv('DB_USERNAME', 'dbadmin')
    password = os.getenv('DB_PASSWORD', 'Perro1201')
    driver = 'ODBC Driver 17 for SQL Server'
    connection_string = f'DRIVER={{{driver}}};SERVER=tcp:{server},1433;DATABASE={database};UID={username};PWD={password};Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30;'
    return pyodbc.connect(connection_string)

#ADMIN CONSOLE PLACE ORDERS ENDPOINT

@app.route('/api/orders', methods=['GET'])
def get_orders():
    print("get_orders API called")  # Debug print
    try:
        conn = get_db_connection()
        cursor = conn.cursor()

        # Get the status parameter from the query string
        status_filter = request.args.get('status')

        base_query = """
        SELECT o.order_id, o.user_id, o.order_date, o.delivery_status, o.product_url, u.name, u.address, u.email, u.phone
        FROM orders o
        INNER JOIN user_info u ON o.user_info_id = u.user_info_id
        """

        # Modify the query based on the status filter
        if status_filter and status_filter != 'All':
            query = base_query + " WHERE o.delivery_status = ?;"
            cursor.execute(query, (status_filter,))
        else:
            query = base_query + ";"
            cursor.execute(query)

        orders = cursor.fetchall()

        # Convert to a list of dictionaries for JSON response
        orders_list = []
        for order in orders:
            orders_list.append({
                "order_id": order[0],
                "user_id": order[1],
                "order_date": order[2].strftime("%Y-%m-%d %H:%M:%S"),
                "delivery_status": order[3],
                "product_url": order[4],
                "recipient_name": order[5],
                "recipient_address": order[6],
                "recipient_email": order[7],
                "recipient_phone": order[8]
            })

        cursor.close()
        conn.close()
        return jsonify(orders_list), 200
    except Exception as e:
        print("Error:", e)
        if conn:
            cursor.close()
            conn.close()
        return jsonify({"error": str(e)}), 500
    

#ADMIN CONSOLE UPDATE ORDERS ENDPOINT

@app.route('/api/orders/update', methods=['POST'])
def update_order_status():
    try:
        data = request.json
        order_id = data['order_id']
        new_status = data['new_status']  # e.g., 'Completed'

        conn = get_db_connection()
        cursor = conn.cursor()

        query = "UPDATE orders SET delivery_status = ? WHERE order_id = ?"
        cursor.execute(query, (new_status, order_id))

        conn.commit()
        cursor.close()
        conn.close()
        return jsonify({"success": True, "order_id": order_id, "new_status": new_status}), 200
    except Exception as e:
        if conn:
            conn.rollback()
            cursor.close()
            conn.close()
        return jsonify({"error": str(e)}), 500




if __name__ == "__main__":
    app.run(port=5020)  

if __name__ == '__main__':
    app.run(debug=True)