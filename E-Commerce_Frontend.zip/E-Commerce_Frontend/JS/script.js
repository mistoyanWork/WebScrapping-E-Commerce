﻿// HEADER
document.addEventListener('DOMContentLoaded', function () {
    fetch('header.html')
        .then(response => response.text())
        .then(data => {
            document.getElementById('header-placeholder').innerHTML = data;
            attachSearchButtonListener();
        });
});

function attachSearchButtonListener() {
    const searchButton = document.querySelector('.search-button');
    if (searchButton) {
        searchButton.addEventListener('click', handleSearch);
    } else {
        console.error('Search button not found');
    }
}

//LOGIN

function openTab(evt, tabName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
}

// Automatically open the first tab when the modal is shown
function openLoginModal() {
    document.getElementById("loginModal").style.display = "block";
    document.getElementsByClassName("tablinks")[0].click(); // Click the first tab
}

function closeLoginModal() {
    var loginModal = document.getElementById("loginModal");
    if (loginModal) {
        loginModal.style.display = "none";
    } else {
        console.error("Login modal not found");
    }
}

// Close the modal when clicking outside of it
window.onclick = function (event) {
    var loginModal = document.getElementById("loginModal");
    if (event.target == loginModal) {
        closeLoginModal();
    }
    // You might also want to check for the product modal here
    var productModal = document.getElementById("product-modal");
    if (event.target == productModal) {
        productModal.style.display = "none";
    }
}



// LOGIN FORM SUBMISSIONS
function handleUserLogin(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const data = {
        username: formData.get('username'),
        password: formData.get('password')
    };
    sendLoginRequest('http://127.0.0.1:5010/login', data, false);
}

function handleAdminLogin(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const data = {
        username: formData.get('admin-username'),
        password: formData.get('admin-password')
    };
    sendLoginRequest('http://127.0.0.1:5010/login', data, true);
}

function sendLoginRequest(url, data, isAdmin) {
    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                sessionStorage.setItem('isLoggedIn', 'true'); // Set the login flag in session storage
                sessionStorage.setItem('userId', data.user_id);
                sessionStorage.setItem('isAdmin', isAdmin);
                updateLoginLogoutButton(); // Update the button based on session storage
                closeLoginModal();

                // Redirect to AdminConsole.html if the user is an admin
                if (isAdmin && data.is_admin) {
                    window.location.href = '/AdminConsole.html';
                }
            } else {
                alert('Login failed: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Login error:', error);
            alert('Login failed: ' + error.message);
        });
}

function updateLoginLogoutButton() {
    var isLoggedIn = sessionStorage.getItem('isLoggedIn') === 'true'; // Retrieve the login flag from session storage
    var loginLogoutButton = document.getElementById('loginLogoutButton');

    if (loginLogoutButton) {
        console.log("Updating login/logout button");
        if (isLoggedIn) {
            loginLogoutButton.textContent = 'Logout';
            loginLogoutButton.onclick = handleLogout;
        } else {
            loginLogoutButton.textContent = 'Login';
            loginLogoutButton.onclick = openLoginModal;
        }
    } else {
        console.error("Login/Logout button not found");
    }
}

// Function to handle logout
function handleLogout() {
    fetch('http://127.0.0.1:5010/logout', {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
        }
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                // Clear session storage
                sessionStorage.removeItem('isLoggedIn');
                sessionStorage.removeItem('userId');
                sessionStorage.removeItem('isAdmin');

                // Update the button to show 'Login' and redirect to index.html
                updateLoginLogoutButton();
                alert('Logout successful');
                window.location.href = 'index.html';  // Redirect to index.html
            } else {
                alert('Logout failed');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while trying to log out');
        });
}


// MutationObserver to wait for the dynamic loading of the header
function updateButtonWhenHeaderLoaded() {
    const observer = new MutationObserver(mutations => {
        mutations.forEach(mutation => {
            if (mutation.addedNodes && mutation.addedNodes.length > 0) {
                const loginLogoutButton = document.getElementById('loginLogoutButton');
                if (loginLogoutButton) {
                    updateLoginLogoutButton();
                    observer.disconnect(); // Stop observing after the button is found and updated
                }
            }
        });
    });

    const config = { childList: true, subtree: true };
    observer.observe(document.body, config);
}

document.addEventListener('DOMContentLoaded', function () {
    updateButtonWhenHeaderLoaded();
});


//FETCHING PRODUCTS-FILTERING-CATEGORIES-SEARCH


// Event listener for DOMContentLoaded
document.addEventListener('DOMContentLoaded', function () {
    // Populate categories and fetch all products on initial load
    const categoryList = document.getElementById('category-list');
    if (!categoryList) {
        console.info('Category list element not found');
        return;
    }
    populateCategories(categoryList);
    fetchAllProducts();
    initFilterRangeListeners();

    // Attach event listener to the search input for the Enter key
    const searchInput = document.querySelector('.search-input');
    if (searchInput) {
        searchInput.addEventListener('keypress', function (event) {
            if (event.key === 'Enter' || event.keyCode === 13) {
                handleSearch();
            }
        });
 
    }

    // Attach event listener to the search button
    const searchButton = document.querySelector('.search-button');
    if (searchButton) {
        searchButton.addEventListener('click', handleSearch);
    } 
});

// Handles the search when the search button is clicked or Enter is pressed
function handleSearch() {
    const searchInput = document.querySelector('.search-input');
    if (searchInput) {
        const searchQuery = searchInput.value.trim();
        if (searchQuery) {
            if (window.location.pathname.includes('ProductFilter.html')) {
                window.location.search = `?query=${encodeURIComponent(searchQuery)}`;
            } else {
                window.location.href = `ProductFilter.html?query=${encodeURIComponent(searchQuery)}`;
            }
        } else {
            console.log('Please enter a search term');
        }
    }
}

// Categories array
const categories = [
    'Phones & Accessories',
    'Computer & Accessories',
    'Gaming',
    'Office Supplies',
    'Auto Detailing',
    'Wheels & Tires',
    'Car Accessories',
    'Sneakers',
    'Boots'
];

// Populates the category list
function populateCategories(categoryList) {
    categories.forEach(category => {
        const listItem = document.createElement('li');
        listItem.textContent = category;
        listItem.onclick = () => fetchProducts(category);
        categoryList.appendChild(listItem);
    });
}

let products = [];
let currentSortedDirection = 'price-low-high';

// Fetches all products on initial load
async function fetchAllProducts() {
    const urlParams = new URLSearchParams(window.location.search);
    const searchQuery = urlParams.get('query');
    let fetchUrl = searchQuery ?
        `http://localhost:5020/api/search?query=${encodeURIComponent(searchQuery)}` :
        `http://localhost:5020/api/all`;

    try {
        const response = await fetch(fetchUrl);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        products = await response.json();
        displayProducts(products);
    } catch (error) {
        console.error('Error fetching products:', error);
        document.getElementById('product-grid').innerHTML = 'Failed to load products.';
    }
}



// Fetches products for a specific category
async function fetchProducts(category, clearGrid = true) {
    const encodedCategory = encodeURIComponent(category);
    const response = await fetch(`http://localhost:5020/api/${encodedCategory}`);

    if (!response.ok) {
        console.error(`Error fetching products for category ${category}:`, response.status);
        return [];
    }

    const fetchedProducts = await response.json();

    if (clearGrid) {
        document.getElementById('product-grid').innerHTML = '';
        products = fetchedProducts; // Update products array with the category's products
    }

    filterAndSortProducts(currentSortedDirection);
    return fetchedProducts;
}

// Filters and sorts products based on the given sort direction and filter criteria
function filterAndSortProducts(sortDirection, filterCriteria = {}) {
    currentSortedDirection = sortDirection;

    let filteredProducts = products.filter(product => {
        if (filterCriteria.maxPrice) {
            const priceRange = product.price.replace(/[^0-9.-]+/g, "").split("-");
            const lowerBoundPrice = parseFloat(priceRange[0]);
            return lowerBoundPrice <= filterCriteria.maxPrice;
        }
        return true;
    });

    filteredProducts.sort((a, b) => {
        const priceA = parseFloat(a.price.replace(/[^0-9.-]+/g, "").split("-")[0]);
        const priceB = parseFloat(b.price.replace(/[^0-9.-]+/g, "").split("-")[0]);
        return sortDirection === 'price-low-high' ? priceA - priceB : priceB - priceA;
    });

    displayProducts(filteredProducts);
}

// Displays products in the UI
function displayProducts(productsToDisplay) {
    const container = document.getElementById('product-grid');
    if (!container) {
        console.error('Product grid element not found');
        return;
    }

    container.innerHTML = '';

    productsToDisplay.forEach(product => {
        const productDiv = document.createElement('div');
        productDiv.className = 'product';

        const image = document.createElement('img');
        image.src = product.picture_url;
        image.alt = product.title;

        const title = document.createElement('h3');
        title.textContent = product.title;

        const price = document.createElement('p');
        price.textContent = product.price;

        productDiv.appendChild(image);
        productDiv.appendChild(title);
        productDiv.appendChild(price);

        productDiv.addEventListener('click', () => openModal(product));
        container.appendChild(productDiv);
    });

    if (productsToDisplay.length === 0) {
        container.innerHTML = 'No products found.';
    }
}

// Initialize event listeners for the price range filter and manual input box
function initFilterRangeListeners() {
    const filterRangeInput = document.getElementById('price-range');
    const manualPriceInput = document.getElementById('manual-price');

    if (filterRangeInput && manualPriceInput) {
        filterRangeInput.addEventListener('input', () => {
            manualPriceInput.value = filterRangeInput.value; // Update manual input box
            updatePriceRange(filterRangeInput.value); // Filter products
        });

        manualPriceInput.addEventListener('change', () => {
            filterRangeInput.value = manualPriceInput.value; // Update filter bar
            updatePriceRange(manualPriceInput.value); // Filter products
        });
    }
}

// Updates the product display based on the selected price range
function updatePriceRange(maxPrice) {
    filterAndSortProducts(currentSortedDirection, { maxPrice: parseFloat(maxPrice) });
}

// Sort products by the selected direction
function sortProducts(direction) {
    filterAndSortProducts(direction);
}


let selectedProductUrl = '';  // Global variable to store the selected product URL

// PRODUCT MODAL OPEN
function openModal(product) {
    document.getElementById('modal-product-image').src = product.picture_url;
    document.getElementById('modal-product-title').textContent = product.title;
    document.getElementById('modal-product-price').textContent = product.price;
    document.getElementById('product-modal').style.display = 'block';

    selectedProductUrl = product.link; // Store the product URL
}




// CHECKOUT MODAL OPEN
function openCheckoutModal(product) {
    document.getElementById('checkout-modal-product-image').src = product.picture_url;
    document.getElementById('checkout-modal-product-title').textContent = product.title;
    document.getElementById('checkout-modal-product-price').textContent = product.price;
    document.getElementById('checkout-modal').style.display = 'block';
    initializePrice();
}

// Function to initialize and store the unit price
function initializePrice() {
    var priceElement = document.getElementById('checkout-modal-product-price');
    if (priceElement) {
        var priceMatch = priceElement.textContent.match(/\$([\d,.]+)/);
        if (priceMatch) {
            averageUnitPrice = parseFloat(priceMatch[1].replace(/,/g, ''));
        }
    }
}

// Function to update price based on quantity
function updatePriceBasedOnQuantity() {
    var quantityInput = document.getElementById('product-quantity');
    var priceElement = document.getElementById('checkout-modal-product-price');
    var quantity = parseInt(quantityInput.value);
    if (priceElement && quantityInput && averageUnitPrice > 0) {
        var totalPrice = (averageUnitPrice * quantity).toFixed(2);
        priceElement.textContent = `Total Price: $${totalPrice}`;
    }
}


// Function to check username and redirect accordingly
function checkUsernameAndRedirect(username) {
    fetch('http://127.0.0.1:5010/check-username', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username })
    })
        .then(response => response.json())
        .then(data => {
            if (data.success && data.exists) {
                // Username exists, open the login modal
                openLoginModal();
            } else {
                // Username does not exist, redirect to registration page
                window.location.href = '/Register.html';
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
}

// Function to open the login modal
function openLoginModal() {
    var loginModal = document.getElementById("loginModal");
    loginModal.style.display = "block";
    loginModal.style.zIndex = "2000"; // High z-index
    document.getElementsByClassName("tablinks")[0].click();
}

// Function to open the checkout modal
function openCheckoutModal(product) {
    closeModal('product-modal'); // Close product modal if open
    var checkoutModal = document.getElementById('checkout-modal');
    checkoutModal.style.display = "block";
    checkoutModal.style.zIndex = "1000"; // Lower z-index than login modal
    // Set product details...
}

// Function to close a modal by id
function closeModal(modalId) {
    var modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = "none";
        modal.style.zIndex = "1"; // Reset z-index
    }
}




// Function to open the checkout modal
function openCheckoutModal(product) {
    document.getElementById('checkout-modal-product-image').src = product.picture_url;
    document.getElementById('checkout-modal-product-title').textContent = product.title;
    document.getElementById('checkout-modal-product-price').textContent = product.price;
    document.getElementById('checkout-modal').style.display = 'block';
    initializePrice();

    // Show the checkout modal
    document.getElementById('checkout-modal').style.display = 'block';
}

// Function to submit the order
function submitOrder() {
    if (!sessionStorage.getItem('isLoggedIn')) {
        alert("Please log in to place an order.");
        openLoginModal();
        return;
    }

    var userId = sessionStorage.getItem('userId');  // Getting the user ID from session storage
    var userName = document.getElementById('user-name').value;
    var userAddress = document.getElementById('user-address').value;
    var userEmail = document.getElementById('user-email').value;
    var userPhone = document.getElementById('user-phone').value;

    var orderData = {
        user_id: userId,
        name: userName,
        address: userAddress,
        email: userEmail,
        phone: userPhone,
        product_url: selectedProductUrl  // Include the product URL in the order data
    };

    fetch('http://localhost:5010/api/purchases', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify(orderData)
    })
        .then(response => {
            if (response.ok) {
                return response.json();
            } else {
                throw new Error('Failed to submit order. Status Code: ' + response.status);
            }
        })
        .then(data => {
            if (data.success) {
                console.log('Order submitted successfully. Order ID:', data.order_id);
                alert("Order placed successfully!");
                closeModal('product-modal'); // Close product modal if open
            } else {
                console.error('Failed to submit order');
                alert("Order placement failed. Please try again.");
            }
        })
        .catch((error) => {
            console.error('Error:', error);
            alert("An error occurred while submitting your order. User ID: " + sessionStorage.getItem('userId'));
        });
}



// Event listeners and modal logic
document.addEventListener('DOMContentLoaded', function () {
    var modal = document.getElementById('product-modal');
    var checkoutModal = document.getElementById('checkout-modal');
    var closeButtons = document.querySelectorAll('.close-button');

    function closeModal(modal) {
        modal.style.display = 'none';
    }

    closeButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            closeModal(modal);
            closeModal(checkoutModal);
        });
    });

    window.addEventListener('click', function (event) {
        if (event.target === modal || event.target === checkoutModal) {
            closeModal(modal);
            closeModal(checkoutModal);
        }
    });

    // 'Buy Now' button logic
    var buyNowButton = document.getElementById('buy-now');
    if (buyNowButton) {
        buyNowButton.addEventListener('click', function () {
            if (!sessionStorage.getItem('isLoggedIn')) {
                // User is not logged in, open the login modal
                openLoginModal();
            } else {
                // User is logged in, open checkout modal
                var product = {
                    title: document.getElementById('modal-product-title').textContent,
                    price: document.getElementById('modal-product-price').textContent,
                    picture_url: document.getElementById('modal-product-image').src
                };
                openCheckoutModal(product);
            }
        });
    }


    // 'Confirm Order' button logic
    var confirmOrderButton = document.getElementById('confirm-order');
    if (confirmOrderButton) {
        confirmOrderButton.addEventListener('click', submitOrder);
    }
});


// CAROUSEL OF PRODUCTS

let slideIndex = 0;
let slides;
let timer;

function createCarouselItem(product, isActive) {
    const itemDiv = document.createElement('div');
    itemDiv.className = `carousel-item ${isActive ? 'active' : ''}`;
    itemDiv.style.display = isActive ? 'block' : 'none'; // Make sure the active item is shown

    const img = document.createElement('img');
    img.src = product.picture_url;
    img.alt = product.title;

    const priceTag = document.createElement('div');
    priceTag.className = 'price';
    priceTag.textContent = `$${product.price}`; // Ensure price is formatted correctly

    itemDiv.appendChild(img);
    itemDiv.appendChild(priceTag);

    return itemDiv;
}

function loadFeaturedProducts() {
    fetch('http://localhost:5020/api/Featured')
        .then(response => response.json())
        .then(data => {
            const carouselInner = document.getElementById('carousel-inner');
            if (!carouselInner) {
                throw new Error('Carousel inner element not found');
            }
            carouselInner.innerHTML = ''; // Clear existing carousel items
            data.forEach((product, index) => {
                const isActive = index === 0;
                const carouselItem = createCarouselItem(product, isActive);
                carouselInner.appendChild(carouselItem);
            });

            slides = document.getElementsByClassName("carousel-item");
            if (slides.length > 0) {
                showSlides(slideIndex); // Start with the first slide
                timer = setTimeout(() => nextSlide(1), 3000); // Start automatic sliding
            }
        })
        .catch(error => {
            console.error('Error loading featured products:', error);
        });
}

function showSlides(n) {
    if (!slides || slides.length === 0) {
        console.error('Slides are not initialized or there are no slides to show.');
        return;
    }

    if (n >= slides.length) { slideIndex = 0; }
    if (n < 0) { slideIndex = slides.length - 1; }

    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    slides[slideIndex].style.display = "block"; // Show the current slide
}

function nextSlide(n) {
    clearTimeout(timer); // Clear existing timer when manually changed
    slideIndex += n;
    if (slideIndex >= slides.length) { slideIndex = 0; }
    if (slideIndex < 0) { slideIndex = slides.length - 1; }
    showSlides(slideIndex);
    timer = setTimeout(() => nextSlide(1), 3000); // Restart automatic sliding
}

// Make sure to call loadFeaturedProducts() after the DOM is fully loaded
document.addEventListener('DOMContentLoaded', loadFeaturedProducts);




